from tkinter import *
import pygame

# defines the application's purpose
print("____              ____    ____      ____      __    __")
print("\   \    ____    /   /   |    |____|    |     \ \  / /")
print(" \   \  /    \  /   /    |    |____     |      \ \/ / ")
print("  \   \/  /\  \/   /     |    |    |    |      |    | ")
print("   \_____/  \_____/      |____|    |____|      |____| ")

groot = Tk()

groot.iconbitmap('rats.ico')
groot.title("Oh Fricc, A Rat!")

pygame.init()
pygame.mixer.init()

def fricc():
    pygame.mixer.music.load("rats.mp3")
    pygame.mixer.music.play()

def ratss():
    pygame.mixer.music.load("ratss.mp3")
    pygame.mixer.music.play()

def bye():
    pygame.mixer.music.stop()

play = lambda: PlaySound('rats.mp3', SND_ALIAS)

help = Button(groot, text = 'Release Minecraft', command = fricc)

help2 = Button(groot, text = 'Sell Minecraft', command = bye)

help3 = Button(groot, text = 'Release Minecraft 2', command = ratss)

help.pack()
help2.pack()
help3.pack()
groot.mainloop()
