import random
from tkinter import *
import sys
import os

# just a seed generator for minecraft


# rng

def seed():
    for i in range(1):
        yield random.randint(-18446744073709551615, 18446744073709551615)
    
# save "seed" to file, where seed is the random number

for random_number in seed():
    Seed=open("seeds.txt","a+")
    Seed.write(str(random_number) + "\n")
    Seed.close()

# root variable is equal to Tk, for ease of access

root = Tk()

# title and icon of the window

root.iconbitmap('RNG-Note.ico')
root.title('RNG Note')

# The window itself

result = Text(root, height=10, width=50)
result.pack(fill = BOTH, expand = YES)
result.insert(END, random_number)

root.mainloop()
